
import React from "react";
import { ShoppingCart, Phone, Mail, Instagram, Facebook } from "lucide-react";
import { motion } from "framer-motion";

function Button({ children, className = "", variant = "solid", ...props }) {
  const base = "px-4 py-2 rounded-md font-semibold focus:outline-none ";
  const variants = {
    solid: "bg-blue-600 text-white hover:bg-blue-700",
    outline: "border border-blue-600 text-blue-600 hover:bg-blue-100",
  };
  return (
    <button className={base + (variants[variant] || variants.solid) + " " + className} {...props}>
      {children}
    </button>
  );
}

function Card({ children, className = "", ...props }) {
  return (
    <div className={"bg-white rounded-2xl shadow-md " + className} {...props}>
      {children}
    </div>
  );
}

function CardContent({ children, className = "", ...props }) {
  return (
    <div className={"p-4 " + className} {...props}>
      {children}
    </div>
  );
}

function Input(props) {
  return (
    <input
      {...props}
      className="border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
    />
  );
}

function Textarea(props) {
  return (
    <textarea
      {...props}
      className="border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
      rows={4}
    />
  );
}

export default function OnlineStore() {
  return (
    <div className="font-sans text-gray-800">
      {/* Header */}
      <header className="bg-white shadow-md p-4 flex justify-between items-center">
        <h1 className="text-2xl font-bold">RK Shopin</h1>
        <Button variant="outline">
          <ShoppingCart className="mr-2 h-5 w-5 inline-block" />
          Cart
        </Button>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-12 text-center">
        <h2 className="text-4xl font-bold mb-4">Welcome to RK Shopin</h2>
        <p className="text-lg mb-6">Discover top products at the best prices!</p>
        <Button className="bg-white text-blue-600 font-bold">Shop Now</Button>
      </section>

      {/* Products Section */}
      <section className="p-8">
        <h3 className="text-3xl font-semibold mb-6 text-center">Featured Products</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map((id) => (
            <Card key={id}>
              <CardContent>
                <img
                  src={`https://via.placeholder.com/300x200?text=Product+${id}`}
                  alt={`Product ${id}`}
                  className="rounded-lg mb-4"
                />
                <h4 className="text-xl font-bold mb-2">Product {id}</h4>
                <p className="text-sm text-gray-600 mb-4">This is a short description of product {id}.</p>
                <Button className="w-full">Add to Cart</Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* About Section */}
      <section className="bg-gray-100 p-8">
        <h3 className="text-3xl font-semibold mb-4 text-center">About Us</h3>
        <p className="max-w-3xl mx-auto text-center text-gray-700">
          At RK Shopin, we aim to provide top-quality products with exceptional service. Whether you're shopping for fashion,
          electronics, or daily needs, we've got you covered.
        </p>
      </section>

      {/* Contact Section */}
      <section className="p-8">
        <h3 className="text-3xl font-semibold mb-6 text-center">Contact Us</h3>
        <div className="max-w-2xl mx-auto grid gap-4">
          <Input type="text" placeholder="Your Name" />
          <Input type="email" placeholder="Your Email" />
          <Textarea placeholder="Your Message" />
          <Button>Send Message</Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white p-6">
        <div className="flex justify-between flex-wrap gap-4 items-center">
          <div>
            <p className="font-bold text-lg">RK Shopin</p>
            <p className="text-sm">&copy; 2025 All rights reserved.</p>
          </div>
          <div className="flex gap-4">
            <Phone className="w-5 h-5" />
            <Mail className="w-5 h-5" />
            <Instagram className="w-5 h-5" />
            <Facebook className="w-5 h-5" />
          </div>
        </div>
      </footer>
    </div>
  );
}
